
module.exports = (sequelize, DataTypes) => {
    const Provider = sequelize.define("Provider", {
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        referral_code:{
            type: DataTypes.STRING,

        },
              provider_type_id:{
            type: DataTypes.INTEGER,
        },
        department_id:{
            type: DataTypes.INTEGER,
        },
        profile_id:{
            type: DataTypes.INTEGER,
        },
        row_state_id: {
            type: DataTypes.INTEGER,
        },
        row_version: {
            type: DataTypes.INTEGER,
        },
        created_by: {
            type: DataTypes.INTEGER,
        },
        modified_by: {
            type: DataTypes.INTEGER,
        },
    });



    Provider.associate = function(models) {
        Provider.belongsTo(models.Profile, {foreignKey: 'profile_id'});
        Provider.hasMany(models.Schedules, {foreignKey: 'provider_id'})

      };


    


    return Provider;
};