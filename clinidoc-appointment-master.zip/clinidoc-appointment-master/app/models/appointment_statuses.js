module.exports = (sequelize, DataTypes) => {
    const appointment_statuses = sequelize.define("appointment_statuses", {
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },  
        status_id: {
            type: DataTypes.INTEGER,
        },
        value: {
            type: DataTypes.STRING,
            allowNull: true,
        },
    });

    return appointment_statuses;
}; //(0,approve),(1,waiting),(2,decline)